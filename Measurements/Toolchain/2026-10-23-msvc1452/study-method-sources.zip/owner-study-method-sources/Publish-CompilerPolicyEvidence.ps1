[CmdletBinding(SupportsShouldProcess)]param([Parameter(Mandatory)][string]$Study)
Set-StrictMode -Version Latest
$ErrorActionPreference='Stop'
$plan=Get-Content -LiteralPath (Join-Path $Study 'plan.json') -Raw|ConvertFrom-Json
$comparison=Get-Content -LiteralPath (Join-Path $Study 'comparison.json') -Raw|ConvertFrom-Json
$complete=Get-Content -LiteralPath (Join-Path $Study 'complete.json') -Raw|ConvertFrom-Json
$name=$plan.repository
if($name-notin @('DxUi','RedXe','RedSalamander','RedPrism','RedTilde')){throw 'Unrecognized measurement owner.'}
$expected=[IO.Path]::GetFullPath("E:\$name.Perf\compiler-policy-study").TrimEnd('\')
$resolved=[IO.Path]::GetFullPath($Study).TrimEnd('\')
if([IO.Path]::GetDirectoryName($resolved)-cne $expected){throw 'Study must be a direct child of its approved owner root.'}
if(-not $complete.passed-or $plan.blocks-ne 12-or $comparison.blocks-ne 12){throw 'Only completed twelve-block studies enter reviewed owner receipts.'}
$id=[IO.Path]::GetFileName($resolved)
$destination=if($name-eq 'RedSalamander'){'E:\RedSalamander.Perf\msvc1452\Specs\TestRuns\Msvc1452ReleaseOptimization_2026-10-23'}else{"E:\$name.Perf\msvc1452\Measurements\Toolchain\2026-10-23-msvc1452"}
$zip=Join-Path $destination ("runtime-$id.zip")
$json=Join-Path $destination ("runtime-$id.json")
$markdown=Join-Path $destination ("runtime-$id.md")
foreach($path in $zip,$json,$markdown){if(Test-Path -LiteralPath $path){throw "Refusing evidence overwrite: $path"}}
if(-not $PSCmdlet.ShouldProcess($destination,'Retain native receipts and reviewed comparison for '+$id)){return}
[void][IO.Directory]::CreateDirectory($destination)
Compress-Archive -LiteralPath $resolved -DestinationPath $zip -CompressionLevel Optimal
if($name-eq 'DxUi'){
 $wrapped=[ordered]@{workloadOwner='DxUi';fixture='dxui-msvc1452-release-policy-20261023';benchmarkInputs=[ordered]@{baselineClosureManifestSha256=$plan.closureIdentities.baseline.manifestSha256;candidateClosureManifestSha256=$plan.closureIdentities.candidate.manifestSha256;harnessSha256=$plan.harnessSha256;activityHelperSha256=$plan.activityHelperSha256};scope='Library-owned WARP complex UI fixture on frozen original/candidate Release policy. This is a compiler-policy experiment, not ordinary matched-profile performance acceptance.';comparison=$comparison}
 $wrapped|ConvertTo-Json -Depth 14|Set-Content -LiteralPath $json
}else{Copy-Item -LiteralPath (Join-Path $resolved 'comparison.json') -Destination $json}
$lines=[Collections.Generic.List[string]]::new()
$lines.Add('# Release compiler-policy runtime comparison')
$lines.Add('')
$lines.Add("Owner: $name. Study: $id. Both sides use MSVC 14.52.37025 and unchanged native fixture inputs; Release optimization policy is the intended difference. This is a bounded fixture result, not whole-product or native ARM64 qualification.")
$lines.Add('')
$lines.Add('| Scenario / metric | Before median | After median | Paired change | Holm p | Unstable controls | Interpretation |')
$lines.Add('| --- | ---: | ---: | ---: | ---: | ---: | --- |')
foreach($row in $comparison.rows){$lines.Add('| '+$row.scenario+' / '+$row.metric+' | '+$row.baselineMedian.ToString('0.###',[cultureinfo]::InvariantCulture)+' | '+$row.candidateMedian.ToString('0.###',[cultureinfo]::InvariantCulture)+' | '+$row.pairedChangePercent.ToString('+0.00;-0.00;0.00',[cultureinfo]::InvariantCulture)+'% | '+$row.adjustedP.ToString('0.####',[cultureinfo]::InvariantCulture)+' | '+$row.unstableControls+' | '+$row.finding+' |')}
$lines.Add('')
$lines.Add('Method: 12 alternating ABBA/BAAB blocks; 24 measured processes per side/scenario, plus one excluded warmup each. Exact two-sided sign-flip p with Holm correction within the repository family; same-side controls use 5% timing/2% memory bands. No significant difference is not proof of non-regression. Raw stdout/stderr, native JSON/TRX, sample receipts, manifests and hashes are retained in ['+[IO.Path]::GetFileName($zip)+']('+[IO.Path]::GetFileName($zip)+').')
$lines.Add('')
$lines.Add('Diagnostic shared-host: '+$comparison.diagnosticSharedHost+'. Samples with observed concurrent build/test activity: '+$comparison.samplesWithCompilationObserved+'. Original failed/noisy attempts remain preserved externally under the approved owner root; a later repeat does not erase them.')
[IO.File]::WriteAllText($markdown,($lines-join "`n")+"`n")
$readme=Join-Path $destination 'README.md'
$text=if(Test-Path $readme){[IO.File]::ReadAllText($readme).TrimEnd()}else{"# MSVC 14.52 Release measurements"}
$text+="`n`nRuntime study [$id](runtime-$id.md) retains the comparison and raw native receipts. Its interpretation explicitly preserves unstable/compilation-contaminated results as inconclusive.`n"
[IO.File]::WriteAllText($readme,$text)
foreach($file in 'ChangedSettings.md','changed-tool-settings.csv'){$from="E:\$name.Perf\reports\Msvc1452ReleaseOptimization_2026-10-23\$file";if(Test-Path $from){Copy-Item -LiteralPath $from -Destination (Join-Path $destination $file)}}
Write-Host "Retained owner runtime evidence: $markdown"